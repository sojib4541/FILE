// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fillCard') {
    fillCard(request.type);
  }
});


// Handle keyboard shortcuts
chrome.commands.onCommand.addListener((command) => {
  if (command === 'decline-card') {
    fillCard('decline');
  } else if (command === 'active-card') {
    fillCard('active');
  }
});

// Shared card filling function
function fillCard(type) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;

    chrome.storage.local.get([
      'activeBin',
      'activeBinExpire',
      'activeBinCvv',
      'declineBin',
      'declineBinExpire',
      'declineBinCvv'
    ], (data) => {
      const isDecline = type === 'decline';

      // Get BIN based on type
      const userBin = isDecline ? data.declineBin : data.activeBin;
      const defaultBin = isDecline ? '546008' : '55988803';

      // Ensure BIN is numeric
      const bin = /^\d+$/.test(userBin) ? userBin : defaultBin;

      // Pad BIN to 16 digits
      const remainingLength = 16 - bin.length;
      const finalCardNumber = bin.length <= 16
        ? generateCardNumber(bin, remainingLength)
        : generateCardNumber(defaultBin, 16 - defaultBin.length);

      // Expiry Date
      const expiry = isDecline
        ? (data.declineBinExpire || generateExpiry())
        : (data.activeBinExpire || generateExpiry());

      // CVV (use stored or generate randomly)
      const cvv = isDecline
        ? (data.declineBinCvv || generateCVV())
        : (data.activeBinCvv || generateCVV());

      const details = {
        name: generateCardName(),
        number: finalCardNumber,
        expiry: expiry,
        cvv: cvv
      };

      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: autofillCardDetails,
        args: [details]
      });
    });
  });
}


const randomWords = [
  'Khan', 'Ahmed', 'Patel', 'Chowdhury', 'Sheikh',
  'Malik', 'Roy', 'Das', 'Hussain', 'Verma',
  'Singh', 'Rahman', 'Sharma', 'Jahan', 'Iqbal',
  'Mondal', 'Rana', 'Mitra', 'Siddiqui', 'Bhattacharya'
];

const randoName = [
  // Male Names (170)
  "Aarav", "Arjun", "Kabir", "Ravi", "Vikram", "Raj", "Ayan", "Zayan", "Rehan", "Tariq",
  "Nasir", "Adeel", "Faizan", "Imran", "Nadeem", "Sameer", "Rahul", "Amit", "Vikas", "Karan",
  "Rohit", "Siddharth", "Manoj", "Abdul", "Yusuf", "Asif", "Irfan", "Shahid", "Kamran", "Waqas",
  "Mehedi", "Sabbir", "Tanvir", "Rakib", "Ashik", "Jubayer", "Hasan", "Arif", "Shakil", "Masud",
  "Niaz", "Towhid", "Arafat", "Habib", "Shuvo", "Tarek", "Munna", "Rubel", "Sumon", "Rasel",
  "Anis", "Harun", "Milton", "Shahin", "Liton", "Jamal", "Ovi", "Saiful", "Faruk", "Delwar",
  "Dip", "Rony", "Bappy", "Aslam", "Sagar", "Sohag", "Biplob", "Ripon", "Alam", "Zahid",
  "Sajid", "Tusher", "Mamun", "Nahid", "Tanim", "Reza", "Mizan", "Tanjil", "Sabbir", "Shohel",
  "Sunny", "Sajol", "Raihan", "Tushar", "Emon", "Shuvo", "Nayan", "Salman", "Parvej", "Pavel",
  "Foysal", "Nafis", "Zubair", "Fahim", "Shahriar", "Shafayet", "Hasib", "Ruman", "Noman", "Imtiaz",
  "Aminul", "Hridoy", "Yamin", "Tawsif", "Nashit", "Rizwan", "Saad", "Bilal", "Talha", "Waleed",
  "Hassan", "Junaid", "Basit", "Hamza", "Adil", "Faris", "Kashif", "Affan", "Zeeshan", "Omar",
  "Danish", "Haroon", "Sami", "Fahad", "Haider", "Sufyan", "Mujtaba", "Ammar", "Zayan", "Usman",
  "Zafar", "Latif", "Rizvi", "Faruq", "Mursalin", "Shahbaz", "Mohtasim", "Ehtesham", "Miraz", "Tawsin",
  "Zakir", "Kawsar", "Sayem", "Abrar", "Mustafiz", "Jubayed", "Obaid", "Minhaz", "Fardin", "Touhid",
  "Shahriar", "Mir", "Bashir", "Tazim", "Rashed", "Araf", "Munzir", "Rakin", "Jahin", "Ahsan",
  "Adnan", "Tahmid", "Rahat", "Tarique", "Saddam", "Sabbir", "Fazle", "Mashrur", "Wasiq", "Arkan",

  // Female Names (30)
  "Ayesha", "Fatima", "Zara", "Anika", "Nusrat", "Priya", "Puja", "Madhuri", "Ameena", "Sadia",
  "Rima", "Sumaiya", "Mehjabin", "Shila", "Nadia", "Sharmin", "Mousumi", "Lamia", "Tasmia", "Hafsa",
  "Sanjida", "Ishrat", "Nargis", "Mahira", "Khadija", "Ruksana", "Lubna", "Rumana", "Farzana", "Naznin"
];


const generateCardName = () => {
  const randomWord = randomWords[Math.floor(Math.random() * randomWords.length)];
  const randomName = randoName[Math.floor(Math.random() * randoName.length)];

  return `${randomName} ${randomWord}`;
};

const generateCardNumber = (prefix, remainingDigits) => {
  let cardNumber = prefix;
  for (let i = 0; i < remainingDigits; i++) {
    cardNumber += Math.floor(Math.random() * 10);
  }
  return luhnCheck(cardNumber);
};

const luhnCheck = (number) => {
  let sum = 0;
  let shouldDouble = false;
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i));
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  if (sum % 10 === 0) return number;
  const lastDigit = parseInt(number.slice(-1));
  const newLastDigit = (lastDigit + (10 - (sum % 10))) % 10;
  return number.slice(0, -1) + newLastDigit;
};

const generateExpiry = () => {
  const currentYear = new Date().getFullYear();
  const year = currentYear + Math.floor(Math.random() * 5) + 1;
  const month = Math.floor(Math.random() * 12) + 1;
  return `${month.toString().padStart(2, '0')}/${year.toString().slice(-2)}`;
};

const generateCVV = () => Math.floor(Math.random() * 900) + 100;

const autofillCardDetails = (details) => {
  const fields = [
    { name: ['cardname', 'card-name', 'cc-name', 'name'], value: details.name },
    { name: ['cardnumber', 'card-number', 'cc-number', 'number'], value: details.number },
    { name: ['expiry', 'exp-date', 'cc-exp', 'expiration'], value: details.expiry },
    { name: ['cvv', 'cvc', 'cc-csc', 'security'], value: details.cvv }
  ];

  fields.forEach(field => {
    field.name.forEach(name => {
      const input = document.querySelector(`input[name*="${name}" i], input[id*="${name}" i]`);
      if (input) {
        input.value = field.value;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  });
};